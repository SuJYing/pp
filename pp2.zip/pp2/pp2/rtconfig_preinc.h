
#ifndef RTCONFIG_PREINC_H__
#define RTCONFIG_PREINC_H__

/* Automatically generated file; DO NOT EDIT. */
/* RT-Thread pre-include file */

#define HAVE_CCONFIG_H
#define RT_USING_LIBC
#define RT_USING_NEWLIB
#define STM32F407xx
#define USE_HAL_DRIVER
#define _POSIX_C_SOURCE 1
#define __RTTHREAD__

#endif /*RTCONFIG_PREINC_H__*/
