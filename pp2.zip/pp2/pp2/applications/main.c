#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <string.h>
#include "onenet.h"
#include "paho_mqtt.h"
#include "aht10.h"
#include "ap3216c.h"

extern rt_bool_t init_ok;
extern MQTTClient mq_client;

#define ONENET_TOPIC_DP       "$sys/XUJ6559qX7/F407/thing/property/post"
#define ONENET_TOPIC_CMD      "$sys/XUJ6559qX7/F407/thing/property/set"  // 命令下发主题
#define TEMP_THRESHOLD        34.0f  // 温度阈值设为30度
#define LED_PIN               GET_PIN(F, 11)  // 报警LED
#define LED2_PIN              GET_PIN(F, 12)  // 新增LED2引脚，根据实际硬件修改
#define KEY1_PIN              GET_PIN(C, 0)  // 新增按键1引脚，根据实际硬件修改

// LED报警状态
static rt_bool_t alarm_active = RT_FALSE;
static rt_timer_t led_timer = RT_NULL;
static rt_bool_t led2_state = RT_FALSE;  // 全局变量，用于记录LED2状态

// LED闪烁定时器回调函数
static void led_toggle(void *parameter)
{
    static rt_bool_t led_state = RT_FALSE;
    led_state = !led_state;
    rt_pin_write(LED_PIN, led_state);
}

// 按键中断回调函数
static void key1_handler(void *args)
{
    // 简单的消抖处理
    rt_thread_mdelay(50);
    if (rt_pin_read(KEY1_PIN)) {
        return;
    }

    // 切换LED2状态
    led2_state = !led2_state;
    rt_pin_write(LED2_PIN, led2_state ? PIN_LOW : PIN_HIGH);
    rt_kprintf("Key1 pressed, LED2 %s\n", led2_state ? "ON" : "OFF");
}

// OneNet命令消息到达回调函数
static void onenet_cmd_handler(MQTTClient *c, MessageData *msg_data)
{
    char *response = RT_NULL;
    char *payload = (char *)msg_data->message->payload;
    int payload_len = msg_data->message->payloadlen;

    rt_kprintf("Received command: %.*s\n", payload_len, payload);

    // 简单的JSON解析，查找LED_Control字段
    // 实际项目中应该使用JSON解析库
    char *led_control = strstr(payload, "\"LED_Control\"");
    if (led_control != RT_NULL) {
        char *value = strstr(led_control, "\"value\"");
        if (value != RT_NULL) {
            char *state = strstr(value, "true");
            if (state != RT_NULL) {
                led2_state = RT_TRUE;
                rt_pin_write(LED2_PIN, PIN_LOW);
                rt_kprintf("LED2 turned ON by command\n");
            } else {
                state = strstr(value, "false");
                if (state != RT_NULL) {
                    led2_state = RT_FALSE;
                    rt_pin_write(LED2_PIN, PIN_HIGH);
                    rt_kprintf("LED2 turned OFF by command\n");
                }
            }
        }
    }

    // 可以在这里添加命令响应
    // ...
}

// 初始化LED和按键
static void hardware_init(void)
{
    // 初始化报警LED引脚
    rt_pin_mode(LED_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(LED_PIN, PIN_HIGH);  // 初始关闭LED

    // 初始化LED2引脚
    rt_pin_mode(LED2_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(LED2_PIN, PIN_HIGH);  // 初始关闭LED2
    led2_state = RT_FALSE;  // 初始状态为关闭

    // 初始化按键1引脚
    rt_pin_mode(KEY1_PIN, PIN_MODE_INPUT_PULLUP);
    rt_pin_attach_irq(KEY1_PIN, PIN_IRQ_MODE_FALLING, key1_handler, RT_NULL);
    rt_pin_irq_enable(KEY1_PIN, PIN_IRQ_ENABLE);

    // 创建报警LED定时器，但不启动
    led_timer = rt_timer_create("led_timer",
                               led_toggle,
                               RT_NULL,
                               500,  // 500ms间隔
                               RT_TIMER_FLAG_PERIODIC | RT_TIMER_FLAG_SOFT_TIMER);
    if (led_timer == RT_NULL)
    {
        rt_kprintf("Failed to create LED timer!\n");
    }
}

// 启动报警
static void start_alarm(void)
{
    if (!alarm_active && led_timer != RT_NULL)
    {
        alarm_active = RT_TRUE;
        rt_timer_start(led_timer);
        rt_kprintf("Temperature alarm activated!\n");
    }
}

// 停止报警
static void stop_alarm(void)
{
    if (alarm_active && led_timer != RT_NULL)
    {
        alarm_active = RT_FALSE;
        rt_timer_stop(led_timer);
        rt_pin_write(LED_PIN, PIN_HIGH);  // 确保LED关闭
        rt_kprintf("Temperature alarm deactivated.\n");
    }
}

// 订阅OneNet命令主题
static void onenet_subscribe_cmd(void)
{
    if (init_ok == RT_TRUE && mq_client.isconnected)
    {
        if (MQTTSubscribe(&mq_client, ONENET_TOPIC_CMD, QOS1, onenet_cmd_handler) != SUCCESS)
        {
            rt_kprintf("Failed to subscribe to command topic!\n");
        }
        else
        {
            rt_kprintf("Subscribed to command topic: %s\n", ONENET_TOPIC_CMD);
        }
    }
}

int main(void)
{
    float humidity, temperature;
    float brightness;
    int32_t ps_data;
    aht10_device_t dev;
    ap3216c_device_t ap_dev;
    const char *aht10_i2c_bus = "i2c3";
    const char *ap3216c_i2c_bus = "i2c2";
    char pub_msg[256];
    MQTTMessage message;

    // 初始化硬件（LED和按键）
    hardware_init();

    // 初始化传感器
    dev = aht10_init(aht10_i2c_bus);
    if (dev == RT_NULL)
    {
        rt_kprintf("the AHT10 sensor initializes failure!\n");
        return 0;
    }

    ap_dev = ap3216c_init(ap3216c_i2c_bus);
    if (ap_dev == RT_NULL)
    {
        rt_kprintf("the AP3216C sensor initializes failure!\n");
        return 0;
    }

    message.qos = QOS1;
    message.retained = 0;

    // 订阅命令主题
    onenet_subscribe_cmd();

    while (1)
    {
        humidity = aht10_read_humidity(dev);
        temperature = aht10_read_temperature(dev);
        brightness = ap3216c_read_ambient_light(ap_dev);
        ps_data = ap3216c_read_ps_data(ap_dev);

        // 温度阈值检测
        if (temperature > TEMP_THRESHOLD)
        {
            start_alarm();
        }
        else
        {
            stop_alarm();
        }

        // 生成 JSON 字符串，包含LED2状态
        snprintf(pub_msg, sizeof(pub_msg),
                "{\"id\": \"1\", \"params\": {\"temperature\": {\"value\": %.1f}, \"humidity\": {\"value\": %.1f}, \"brightness\": {\"value\": %.1f}, \"ps_data\": {\"value\": %ld}, \"LED_Control\": {\"value\": %s}}}",
                temperature, humidity, brightness, ps_data, led2_state ? "true" : "false");

        message.payload = (void *)pub_msg;
        message.payloadlen = rt_strlen(pub_msg);

        if (init_ok == RT_TRUE && mq_client.isconnected)
        {
            MQTTPublish(&mq_client, ONENET_TOPIC_DP, &message);
            rt_memset(pub_msg, 0, sizeof(pub_msg));
        }

        rt_thread_mdelay(5000);
        // 伪代码示例（设备端）

    }

    // 清理资源
    if (led_timer != RT_NULL)
    {
        rt_timer_delete(led_timer);
    }

    return RT_EOK;
}
