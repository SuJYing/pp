#ifndef SENSORS_H__
#define SENSORS_H__

#include <rtthread.h>

/* 传感器初始化函数 */
rt_err_t sensors_init(void);

/* 传感器数据读取函数 */
void sensors_read_data(void);

/* 传感器去初始化函数 */
void sensors_deinit(void);

#endif /* SENSORS_H__ */
