#include "sensors.h"
#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include "aht10.h"
#include "ap3216c.h"
#include "icm20608.h"

#define DBG_TAG "SENSORS"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

/* 传感器设备句柄 */
static aht10_device_t aht10_dev = RT_NULL;
static ap3216c_device_t ap3216c_dev = RT_NULL;
static icm20608_device_t icm20608_dev = RT_NULL;

/* 定时器用于周期读取传感器数据 */
static rt_timer_t sensors_timer = RT_NULL;

/* 传感器数据读取线程 */
static void sensors_entry(void *parameter)
{
    while (1)
    {
        /* 读取AHT10温湿度数据 */
        if (aht10_dev != RT_NULL)
        {
            float humidity, temperature;
            humidity = aht10_read_humidity(aht10_dev);
            LOG_D("AHT10 - humidity: %d.%d %%", (int)humidity, (int)(humidity * 10) % 10);

            temperature = aht10_read_temperature(aht10_dev);
            LOG_D("AHT10 - temperature: %d.%d", (int)temperature, (int)(temperature * 10) % 10);
        }

        /* 读取AP3216C光照和接近数据 */
        if (ap3216c_dev != RT_NULL)
        {
            rt_uint16_t ps_data;
            float brightness;

            ps_data = ap3216c_read_ps_data(ap3216c_dev);
            if (ps_data == 0)
            {
                LOG_D("AP3216C - object is not proximity of sensor.");
            }
            else
            {
                LOG_D("AP3216C - current ps data: %d.", ps_data);
            }

            brightness = ap3216c_read_ambient_light(ap3216c_dev);
            LOG_D("AP3216C - current brightness: %d.%d(lux).",
                 (int)brightness, ((int)(10 * brightness) % 10));
        }

        /* 读取ICM20608六轴数据 */
        if (icm20608_dev != RT_NULL)
        {
            rt_int16_t accel_x, accel_y, accel_z;
            rt_int16_t gyros_x, gyros_y, gyros_z;
            rt_err_t result;

            result = icm20608_get_accel(icm20608_dev, &accel_x, &accel_y, &accel_z);
            if (result == RT_EOK)
            {
                LOG_D("ICM20608 - accel: X%6d, Y%6d, Z%6d", accel_x, accel_y, accel_z);
            }

            result = icm20608_get_gyro(icm20608_dev, &gyros_x, &gyros_y, &gyros_z);
            if (result == RT_EOK)
            {
                LOG_D("ICM20608 - gyro: X%6d, Y%6d, Z%6d", gyros_x, gyros_y, gyros_z);
            }
        }

        rt_thread_mdelay(1000); /* 1秒读取一次 */
    }
}

/* 定时器回调函数 */
static void sensors_timeout_callback(void *parameter)
{
    /* 这里可以添加定时触发的操作 */
}

/* 初始化所有传感器 */
rt_err_t sensors_init(void)
{
    /* 初始化AHT10温湿度传感器 */
    aht10_dev = aht10_init("i2c3");
    if (aht10_dev == RT_NULL)
    {
        LOG_E("AHT10 sensor initializes failure");
    }
    else
    {
        LOG_D("AHT10 sensor initializes success");
    }

    /* 初始化AP3216C光照和接近传感器 */
    ap3216c_dev = ap3216c_init("i2c2");
    if (ap3216c_dev == RT_NULL)
    {
        LOG_E("AP3216C sensor initializes failure");
    }
    else
    {
        LOG_D("AP3216C sensor initializes success");
    }

    /* 初始化ICM20608六轴传感器 */
    icm20608_dev = icm20608_init("i2c2");
    if (icm20608_dev == RT_NULL)
    {
        LOG_E("ICM20608 sensor initializes failure");
    }
    else
    {
        LOG_D("ICM20608 sensor initializes success");

        /* 对ICM20608进行零值校准 */
        rt_err_t result = icm20608_calib_level(icm20608_dev, 10);
        if (result == RT_EOK)
        {
            LOG_D("ICM20608 calibrates success");
            LOG_D("accel_offset: X%6d  Y%6d  Z%6d",
                 icm20608_dev->accel_offset.x,
                 icm20608_dev->accel_offset.y,
                 icm20608_dev->accel_offset.z);
            LOG_D("gyro_offset : X%6d  Y%6d  Z%6d",
                 icm20608_dev->gyro_offset.x,
                 icm20608_dev->gyro_offset.y,
                 icm20608_dev->gyro_offset.z);
        }
        else
        {
            LOG_E("ICM20608 calibrates failure");
            icm20608_deinit(icm20608_dev);
            icm20608_dev = RT_NULL;
        }
    }

    /* 创建传感器数据读取线程 */
    rt_thread_t sensors_thread = rt_thread_create("sensors",
                                                sensors_entry,
                                                RT_NULL,
                                                2048,
                                                RT_THREAD_PRIORITY_MAX / 2,
                                                20);
    if (sensors_thread != RT_NULL)
    {
        rt_thread_startup(sensors_thread);
    }
    else
    {
        LOG_E("Failed to create sensors thread");
        return RT_ERROR;
    }

    /* 创建定时器，周期触发传感器读取 */
    sensors_timer = rt_timer_create("sensors_timer",
                                   sensors_timeout_callback,
                                   RT_NULL,
                                   RT_TICK_PER_SECOND * 1,
                                   RT_TIMER_FLAG_PERIODIC);
    if (sensors_timer != RT_NULL)
    {
        rt_timer_start(sensors_timer);
    }

    return RT_EOK;
}

/* 去初始化所有传感器 */
void sensors_deinit(void)
{
    /* 停止定时器 */
    if (sensors_timer != RT_NULL)
    {
        rt_timer_stop(sensors_timer);
        rt_timer_delete(sensors_timer);
        sensors_timer = RT_NULL;
    }

    /* 去初始化传感器 */
    if (aht10_dev != RT_NULL)
    {
        aht10_deinit(aht10_dev);
        aht10_dev = RT_NULL;
    }

    if (ap3216c_dev != RT_NULL)
    {
        ap3216c_deinit(ap3216c_dev);
        ap3216c_dev = RT_NULL;
    }

    if (icm20608_dev != RT_NULL)
    {
        icm20608_deinit(icm20608_dev);
        icm20608_dev = RT_NULL;
    }

    LOG_D("All sensors deinitialized");
}
